class WccBoardCard extends HTMLElement {
  setConfig(c) { this._c = c || {}; this._idx = null; this._gIdx = null; }
  set hass(h) { this._h = h; }
  connectedCallback() {
    this._run();
    const ms = (this._c.refresh_seconds || 30) * 1000;
    this._t = setInterval(() => { if (!document.hidden) this._run(); }, ms);
  }
  disconnectedCallback() { clearInterval(this._t); }

  async _run() {
    const sb = [
      ["r","n","b","q","k","b","n","r"],["p","p","p","p","p","p","p","p"],
      ["","","","","","","",""],["","","","","","","",""],
      ["","","","","","","",""],["","","","","","","",""],
      ["P","P","P","P","P","P","P","P"],["R","N","B","Q","K","B","N","R"]
    ];
    try {
      const tid = this._c.tournament_id || "qfkdt8mn";
      const u = "https://" + "lichess.org/api/broadcast/" + tid + ".pgn";
      const res = await fetch(u);
      if (!res.ok) throw new Error("HTTP " + res.status);
      const pgn = await res.text();
      if (!pgn.includes("[Event")) {
        this._games = [];
        return this._draw(sb, "Gukesh Dommaraju", "Javokhir Sindarov",
          "WCC 2026", "Waiting for moves", "0.0", 50, [], 0, 0);
      }
      const all = pgn.trim().split(/\n\n(?=\[Event)/);
      const act = all.filter(g => /\b1\.\s/.test(g.split("\n\n").at(-1)));
      const list = act.length ? act : all;
      const wasLatest = this._gIdx === null ||
        (this._games && this._gIdx >= this._games.length - 1);
      this._games = list.map((g, i) => this._parseGame(g, i));
      if (wasLatest) {
        this._gIdx = this._games.length - 1;
        this._idx = null;
      } else {
        this._gIdx = Math.min(this._gIdx, this._games.length - 1);
      }
      this._sb = sb;
      this._renderIdx();
    } catch (e) {
      this._draw(sb, "Gukesh", "Sindarov", "WCC 2026",
        e.message, "0.0", 50, [], 0, 0);
    }
  }
  _parseGame(g, i) {
    const rnd = (g.match(/\[Round "([^"]+)"\]/) || []).at(1) || String(i + 1);
    const w = (g.match(/\[White "([^"]+)"\]/) || []).at(1) || "Gukesh";
    const b = (g.match(/\[Black "([^"]+)"\]/) || []).at(1) || "Sindarov";
    const hdrRes = (g.match(/\[Result "([^"]+)"\]/) || []).at(1) || "*";
    const tid = this._c.tournament_id || "qfkdt8mn";
    const fallback = "https://" + "lichess.org/broadcast/" +
      "fide-world-chess-championship-2026/" + tid + "#boards";
    const gUrl = (g.match(/\[GameURL "([^"]+)"\]/) ||
      g.match(/\[Site "(https:\/\/lichess\.org\/broadcast\/[^"]+)"\]/) || [])
      .at(1) || fallback;
    const raw = g.split("\n\n").at(-1);
    const txt = raw.replace(/\{[^}]*\}|\([^)]*\)/g, "").trim();
    const parts = txt.split(/\s+/).filter(Boolean);
    const endTok = parts.at(-1);
    const finalRes = ["1-0", "0-1", "1/2-1/2"].includes(endTok) ? endTok :
      (["1-0", "0-1", "1/2-1/2"].includes(hdrRes) ? hdrRes : "");
    const skip = ["1-0", "0-1", "1/2-1/2", "*"];
    const tok = parts.filter(t => !t.includes(".") && !skip.includes(t));
    const evs = [...raw.matchAll(/\[%eval ([^\]]+)\]/g)].map(m => m.at(1));
    const gNum = rnd.split(".").at(0);
    const badge = finalRes === "1/2-1/2" ? " (½-½)" :
      finalRes ? ` (${finalRes})` : " (Live)";
    return { label: `Game ${gNum}${badge}`, rnd, w, b, finalRes, tok, evs, url: gUrl };
  }

  _renderIdx() {
    if (!this._games || !this._games.length) return;
    const st = this._games.at(this._gIdx);
    const { w, b, rnd, finalRes, tok, evs, url } = st;
    const prevMax = this._lastLen ?? tok.length;
    const followLive = this._idx === null || this._idx >= prevMax;
    const cur = followLive ? tok.length :
      Math.max(0, Math.min(this._idx, tok.length));
    this._idx = cur;
    this._lastLen = tok.length;
    const slice = tok.slice(0, cur);
    const { board, hl } = this._play(this._sb, slice);
    let lbl = "0.0", pct = 50;
    if (cur > 0 && evs.length >= cur) {
      const e = evs.at(cur - 1);
      if (e.startsWith("#")) {
        const m = parseInt(e.slice(1), 10);
        lbl = "M" + Math.abs(m);
        pct = m > 0 ? 100 : 0;
      } else {
        const cp = parseFloat(e);
        lbl = (cp > 0 ? "+" : "") + cp.toFixed(1);
        pct = Math.round(50 + 50 * (2 / (1 + Math.exp(-0.37 * cp)) - 1));
      }
    } else if (cur > 0) {
      const cp = this._eval(board, cur % 2 === 0);
      lbl = (cp > 0 ? "+" : "") + cp.toFixed(1);
      pct = Math.round(50 + 50 * (2 / (1 + Math.exp(-0.37 * cp)) - 1));
    }
    const atEnd = cur === tok.length;
    if (atEnd && finalRes === "1/2-1/2") { lbl = "0.0"; pct = 50; }
    const n = Math.ceil(cur / 2);
    const dot = cur % 2 === 1 ? "." : "...";
    const lm = cur ? `${n}${dot} ${slice.at(-1)}` : "Starting position";
    const resTxt = atEnd ? (
      finalRes === "1-0" ? ` — ${w} Wins! (1-0)` :
      finalRes === "0-1" ? ` — ${b} Wins! (0-1)` :
      finalRes === "1/2-1/2" ? " — Game Drawn (½-½)" : ""
    ) : ` (Move ${cur}/${tok.length})`;
    const ft = tok.length ? `${cur ? "Move: " + lm : lm}${resTxt}` :
      "Waiting for moves";
    this._draw(board, w, b, "Round " + rnd, ft, lbl, pct, hl, cur, tok.length, url);
  }
  _eval(b, wTurn) {
    const v = {P:1,N:3.2,B:3.3,R:5,Q:9,p:-1,n:-3.2,b:-3.3,r:-5,q:-9};
    let s = wTurn ? 0.15 : -0.15;
    for (let r = 0; r < 8; r++) {
      for (let f = 0; f < 8; f++) {
        const p = b.at(r).at(f);
        if (!p) continue;
        s += v[p] || 0;
        const cb = (3.5 - Math.abs(3.5 - r)) * 0.04 +
                   (3.5 - Math.abs(3.5 - f)) * 0.04;
        if ("NBRQ".includes(p)) s += cb;
        if ("nbrq".includes(p)) s -= cb;
      }
    }
    return Math.round(s * 10) / 10;
  }

  _play(b, moves) {
    const bd = b.map(r => [...r]);
    let hl = [];
    moves.forEach((san, idx) => {
      const isW = idx % 2 === 0;
      const m = san.replace(/[+#!?]/g, "");
      if (m === "O-O" || m === "0-0") {
        const ri = isW ? 7 : 0, row = bd.at(ri);
        row.splice(6, 1, row.at(4)); row.splice(4, 1, "");
        row.splice(5, 1, row.at(7)); row.splice(7, 1, "");
        hl = [`${ri},4`, `${ri},6`]; return;
      }
      if (m === "O-O-O" || m === "0-0-0") {
        const ri = isW ? 7 : 0, row = bd.at(ri);
        row.splice(2, 1, row.at(4)); row.splice(4, 1, "");
        row.splice(3, 1, row.at(0)); row.splice(0, 1, "");
        hl = [`${ri},4`, `${ri},2`]; return;
      }
      const pr = m.includes("=") ? m.split("=").at(1) : null;
      const core = m.split("=").at(0);
      const tf = "abcdefgh".indexOf(core.slice(-2, -1));
      const tr = 8 - parseInt(core.slice(-1), 10);
      if (tf < 0 || isNaN(tr)) return;
      const pc = /^[KQRBN]/.test(core) ? core.at(0) : "P";
      const piece = isW ? pc : pc.toLowerCase();
      const hint = core.slice(/^[KQRBN]/.test(core) ? 1 : 0, -2)
                       .replace("x", "");
      for (let r = 0; r < 8; r++) {
        for (let f = 0; f < 8; f++) {
          if (bd.at(r).at(f) !== piece) continue;
          if (hint && !hint.includes("abcdefgh".at(f)) &&
              !hint.includes(String(8 - r))) continue;
          if (this._reach(bd, pc, isW, r, f, tr, tf, core.includes("x"))) {
            if (pc === "P" && core.includes("x") && !bd.at(tr).at(tf)) {
              bd.at(r).splice(tf, 1, "");
            }
            bd.at(tr).splice(tf, 1, pr ? (isW ? pr : pr.toLowerCase()) : piece);
            bd.at(r).splice(f, 1, "");
            hl = [`${r},${f}`, `${tr},${tf}`];
            return;
          }
        }
      }
    });
    return { board: bd, hl };
  }

  _reach(b, p, isW, r1, f1, r2, f2, cap) {
    const dr = r2 - r1, df = f2 - f1, adr = Math.abs(dr), adf = Math.abs(df);
    if (p === "N") return (adr === 2 && adf === 1) || (adr === 1 && adf === 2);
    if (p === "K") return adr <= 1 && adf <= 1;
    if (p === "P") {
      const d = isW ? -1 : 1;
      if (!cap && df === 0 && dr === d && !b.at(r2).at(f2)) return true;
      if (!cap && df === 0 && dr === 2 * d && r1 === (isW ? 6 : 1) &&
          !b.at(r1 + d).at(f1) && !b.at(r2).at(f2)) return true;
      return cap && adf === 1 && dr === d;
    }
    if (p === "R" && dr !== 0 && df !== 0) return false;
    if (p === "B" && adr !== adf) return false;
    if (p === "Q" && dr !== 0 && df !== 0 && adr !== adf) return false;
    const sr = Math.sign(dr), sf = Math.sign(df);
    for (let r = r1 + sr, f = f1 + sf; r !== r2 || f !== f2; r += sr, f += sf) {
      if (b.at(r).at(f)) return false;
    }
    return true;
  }
  _svg(p) {
    if (!p) return "";
    const side = p === p.toUpperCase() ? "w" : "b";
    const code = side + p.toUpperCase();
    const base = "https://" + "lichess1.org/assets/piece/cburnett/";
    return `<img src="${base}${code}.svg" class="pc" alt="${code}">`;
  }

  _draw(board, w, b, sub, ft, lbl, pct, hl, cur, max, gameUrl) {
    const fs = ["a","b","c","d","e","f","g","h"];
    const cells = board.flatMap((r, ri) => r.map((p, fi) => {
      const lt = (ri + fi) % 2 === 0;
      const isHl = hl.includes(`${ri},${fi}`);
      const rl = fi === 0 ? `<span class="c rk">${8 - ri}</span>` : "";
      const fl = ri === 7 ? `<span class="c fl">${fs.at(fi)}</span>` : "";
      return `<div class="sq ${lt?"lt":"dk"} ${isHl?"hl":""}">` +
             `${rl}${fl}${this._svg(p)}</div>`;
    })).join("");
    const tid = this._c.tournament_id || "qfkdt8mn";
    const u = gameUrl || ("https://" + "lichess.org/broadcast/" +
              "fide-world-chess-championship-2026/" + tid + "#boards");
    const d0 = cur <= 0 ? "disabled" : "";
    const d1 = cur >= max ? "disabled" : "";
    const opts = (this._games || []).map((gm, idx) =>
      `<option value="${idx}" ${idx === this._gIdx ? "selected" : ""}>` +
      `${gm.label}</option>`
    ).join("");
    const selHtml = opts ? `<select id="g-sel" class="gs">${opts}</select>` : "";
    this.innerHTML = `<ha-card style="padding:18px">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:4px;flex-wrap:wrap">
        <div style="font-weight:600;font-size:16px">🏆 FIDE World Chess Championship 2026</div>
        ${selHtml}
      </div>
      <div style="font-size:13px;color:var(--secondary-text-color);margin-bottom:12px">
        ${sub}</div>
      <div style="width:100%;max-width:460px;margin:0 auto 10px">
        <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:4px;color:var(--secondary-text-color)">
          <span>⬜ White</span><b>${lbl}</b><span>⬛ Black</span>
        </div>
        <div style="height:12px;width:100%;background:#312e2b;border-radius:6px;overflow:hidden;border:1px solid var(--divider-color)">
          <div style="height:100%;width:${pct}%;background:#f9f9f9;transition:width 0.3s ease"></div>
        </div>
      </div>
      <div style="text-align:center;font-size:14px;margin-bottom:8px">⬛ <b>${b}</b></div>
      <div class="bd">${cells}</div>
      <div style="text-align:center;font-size:14px;margin-top:8px">⬜ <b>${w}</b></div>
      <div style="display:flex;justify-content:center;gap:10px;margin-top:12px">
        <button id="b-first" class="nb" ${d0} title="First move">|&lt;</button>
        <button id="b-prev" class="nb" ${d0} title="Previous move">&lt;</button>
        <button id="b-next" class="nb" ${d1} title="Next move">&gt;</button>
        <button id="b-last" class="nb" ${d1} title="Last / Live move">&gt;|</button>
      </div>
      <div style="text-align:center;font-size:13px;margin-top:10px;font-weight:500">${ft}</div>
      <div style="text-align:center;margin-top:12px">
        <a href="${u}" target="_blank" style="display:inline-block;padding:8px 16px;border-radius:6px;background:#739552;color:#fff;text-decoration:none;font-size:13px;font-weight:600">Open Board on Lichess ↗</a>
      </div>
      <style>
        .bd{display:grid;grid-template-columns:repeat(8,1fr);grid-template-rows:repeat(8,1fr);width:100%;max-width:460px;aspect-ratio:1/1;margin:0 auto;border:2px solid #739552;border-radius:4px;overflow:hidden}
        .sq{position:relative;width:100%;height:100%;display:flex;align-items:center;justify-content:center}
        .lt{background:#ebecd0;color:#739552}
        .dk{background:#739552;color:#ebecd0}
        .lt.hl{background:#f5f682;color:#739552}
        .dk.hl{background:#b9ca43;color:#ebecd0}
        .c{position:absolute;font-size:12px;font-weight:700;line-height:1;pointer-events:none}
        .rk{top:3px;left:4px}
        .fl{bottom:3px;right:4px}
        .pc{width:88%;height:88%;object-fit:contain;user-select:none;pointer-events:none}
        .nb{padding:7px 16px;border:1px solid #739552;border-radius:6px;background:var(--secondary-background-color);color:var(--primary-text-color);font-weight:700;font-size:14px;cursor:pointer}
        .nb:disabled{opacity:0.35;cursor:default}
        .gs{padding:5px 10px;border:1px solid #739552;border-radius:6px;background:var(--secondary-background-color);color:var(--primary-text-color);font-weight:600;font-size:13px;cursor:pointer}
      </style>
    </ha-card>`;
    const sel = this.querySelector("#g-sel");
    if (sel) sel.onchange = (e) => {
      this._gIdx = parseInt(e.target.value, 10);
      this._idx = null;
      this._lastLen = null;
      this._renderIdx();
    };
    this.querySelector("#b-first").onclick = () => { this._idx = 0; this._renderIdx(); };
    this.querySelector("#b-prev").onclick = () => { this._idx = Math.max(0, cur - 1); this._renderIdx(); };
    this.querySelector("#b-next").onclick = () => { this._idx = Math.min(max, cur + 1); this._renderIdx(); };
    this.querySelector("#b-last").onclick = () => { this._idx = max; this._renderIdx(); };
  }
  getCardSize() { return 12; }
}
customElements.define("wcc-board-card", WccBoardCard);
